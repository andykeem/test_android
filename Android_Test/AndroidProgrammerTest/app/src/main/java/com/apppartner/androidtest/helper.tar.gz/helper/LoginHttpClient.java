package com.apppartner.androidtest.helper;

import android.os.Bundle;

import java.util.Map;

/**
 * Created by foo on 2/17/18.
 */

public class LoginHttpClient extends HttpClient {

    protected static final String TAG = LoginHttpClient.class.getSimpleName();

    public LoginHttpClient() {
        mPath = "AppPartnerDeveloperTest/scripts/login.php";
    }

    public String login() {
        String resp = this.getUrlString();
        return resp;
    }
}
