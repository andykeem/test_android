package com.apppartner.androidtest.helper;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class HttpClient {

    protected static final String TAG = HttpClient.class.getSimpleName();
    protected static final String HOST = "http://dev3.apppartner.com/";
    protected String mPath;
    protected Bundle mParams = new Bundle();

    protected Uri getEndpoint() {
        Uri.Builder builder = Uri.parse(HOST).buildUpon();
        if (mPath != null) {
            builder.appendEncodedPath(mPath);
        }
        for (String key : mParams.keySet()) {
            String val = mParams.getString(key);
            builder.appendQueryParameter(key, val);
        }
        return builder.build();
    }

    public String getUrlString() {
        String url = this.getEndpoint().toString();
        Log.d(TAG, "url: " + url);
        try {
            byte[] bytes = this.getUrlBytes(url);
            if (bytes == null) {
                return null;
            }
            String resp = new String(bytes);
            return resp;
        } catch (IOException ioe) {
            Log.e(TAG, ioe.getMessage(), ioe);
        }
        return null;
    }

    protected byte[] getUrlBytes(String spec) throws IOException {
        HttpURLConnection conn = null;
        InputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            URL url = new URL(spec);
            conn = (HttpURLConnection) url.openConnection();
            int respCode = conn.getResponseCode();
            if (respCode != HttpURLConnection.HTTP_OK) {
                return null;
            }
            in = conn.getInputStream();
            out = new ByteArrayOutputStream();
            byte[] bytes = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = in.read(bytes)) > -1) {
                out.write(bytes, 0, bytesRead);
            }
            out.close();
            in.close();
            return out.toByteArray();
        } catch (MalformedURLException mue) {
            Log.e(TAG, mue.getMessage(), mue);
        } catch (IOException ioe) {
            Log.e(TAG, ioe.getMessage(), ioe);
        } finally {
            conn.disconnect();
        }
        return null;
    }

    public HttpClient setParams(Bundle params) {
        mParams = params;
        return this;
    }
}
